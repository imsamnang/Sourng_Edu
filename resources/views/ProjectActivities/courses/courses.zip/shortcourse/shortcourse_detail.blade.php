@extends('projectactivities.layout.master')

@section('menu-panel')
@include('projectactivities.layout.menu.menu_admin')
@endsection

@section('css')
    
@endsection
@section('content')
  
<div class="card table-bordered" style="margin-top: 15px; margin-left: 15px; margin-right: 15px; padding-left: 30px; padding-right: 30px; padding-bottom: 30px; padding-top: 5px; border-color: #79b0ce;">
        <b><hr></b>
        <h4 style="color: white; font-family: Khmer OS Battambang;
         background-color: #438eb9; padding: 10px;">Short Course Detail</h4>
        <b><hr></b>
        <div class="card-body">
            <form>
                <table class="table table-bordered">
                        <thead>
                          <tr>
                            <div class="col-md-6">
                            <th>Course Code <label>hkjhkh</label></th>
                            </div>

                            <div class="col-md-6">
                            <th>Lastname</th>
                            </div>
                            
                          </tr>
                        </thead>
                      </table>
            </form>
        </div>
      </div>
@endsection
@section('js')
    
@endsection
