       @extends('projectactivities.layout.master')

       @section('css')
       <!-- page specific plugin styles -->
       <link rel="stylesheet" href="{{ asset('assets/font-awesome/4.5.0/css/font-awesome.min.css') }}" />
       <link rel="stylesheet" href="{{ asset('assets/css/jquery-ui.custom.min.css') }}" />
       <link rel="stylesheet" href="{{ asset('assets/css/bootstrap-datepicker3.min.css') }}" />
       @endsection

       @section('menu-panel')
       @include('projectactivities.layout.menu.menu_admin')
       @endsection

       @section('content')
       @if($message = Session::get('success'))
       <div class="alert alert-success">
        <p>{{ $message }}</p>
    </div>
    @endif
    <div class="row" style="margin-left: 10px; margin-right: 10px;">
       <div class="col-xs-12">
          <h4 class="header large lighter blue"><i class="fa fa-list" aria-hidden="true"></i>&nbsp; {{ __('shortcoure_ShortCourseList') }}</h4>
          <div class="clearfix" style="margin-bottom: 15px;">

             <span class="easy-link-menu">
                <a href="{{ route('shortcourse.save') }}" class="btn-success btn-sm bulk-action-btn" attr-action-type="active"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp;@lang('btn_st_Add')</a>
                <a class="btn-primary btn-sm bulk-action-btn" attr-action-type="active"><i class="fa fa-check" aria-hidden="true"></i>&nbsp;@lang('btn_st_Active')</a>
                <a class="btn-warning btn-sm bulk-action-btn" attr-action-type="in-active"><i class="fa fa-remove" aria-hidden="true"></i>&nbsp;@lang('btn_st_inActive')</a>
                <a class="btn-danger btn-sm bulk-action-btn" attr-action-type="delete"><i class="fa fa-trash" aria-hidden="true"></i>&nbsp;@lang('btn_st_Delete')</a>
            </span>

            <span class="pull-right tableTools-container"></span>
        </div>
        <div class="table-header">
         {{-- {{ $panel }}​ @lang('Panel_st_Record')  --}}
     </div>
     <!-- div.table-responsive -->
     <!-- div.table-responsive -->
     <div class="table-responsive">
         {!! Form::open() !!}
         <table id="dynamic-table" class="table table-striped table-bordered table-hover">

            <thead>
               <tr>
                  <th class="center">
                     <label class="pos-rel">
                        <input type="checkbox" class="ace" />
                        <span class="lbl"></span>
                    </label>
                </th>
                <th>{{ __('shortcoure_id') }}</th>
                <th>{{ __('shortcoure_Course_Name') }}</th>
                <th>{{ __('shortcoure_Course-Code') }}</th>
                <th width="115px;">{{ __('shortcoure_Action') }}</th>

            </tr>
        </thead>
        <tbody>
          @foreach ($shortcourse as $key=> $post)
          <tr>
             <td class="center first-child">
                <label>
                    <input type="checkbox" name="chkIds[]" value="{{ $post->id }}" class="ace" />
                    <span class="lbl"></span>
                </label>
            </td>
            {{-- <td>{{$key+1}}</td> --}}
            <td>{{$post->course_code_id}}</td>
            <td>{{$post->course_name}}</td>
            <td>{{$post->total_training_hour}}</td>
            <td>

                <a href="#" class="btn btn-primary btn-minier btn-primary">
                    <i class="ace-icon fa fa-eye bigger-130"></i>
                </a>

                <a href="{{ route('edit-shortcourse.edit',$post->id) }}" class="btn btn-primary btn-minier btn-success">
                    <i class="ace-icon fa fa-pencil bigger-130"></i>
                </a>

                {{-- <button type="submit" class="btn btn-xs btn-danger" onclick="deletePost({{$post->id}})" style="padding-left: 5px; padding-right: 5px; padding-top: 0px; padding-bottom: 0px;"><i class="ace-icon fa fa-trash-o bigger-130"></i></button> --}}

                <form id="delete-form-{{$post->id}}" action="{{ route('delete-shortcourse.destroy',$post->id) }}"
                  method="POST" style="display: none">
                  @csrf
                  @method('DELETE')
                </form>

                 <button type="button" class="btn btn-xs btn-danger" onclick="deletePost({{$post->id}})" style="padding-left: 5px; padding-right: 5px; padding-top: 0px; padding-bottom: 0px;"><i class="ace-icon fa fa-trash-o bigger-130"></i></button>

                 <form id="delete-form-{{$post->id}}" action="{{ route('delete-shortcourse.destroy',$post->id) }}"
                  method="POST" style="display: none">
                  @csrf
                  @method('DELETE')
              </form>


          </td>
      </tr>
      @endforeach



  </tbody>
</table>
{!! Form::close() !!}

</div>
</div>
</div>

@endsection

@section('js')
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


@include('includes.scripts.inputMask_script')
@include('includes.scripts.datepicker_script')

        <script type="text/javascript">
          function deletePost(id){
            const swalWithBootstrapButtons = swal.mixin({
              confirmButtonClass: 'btn btn-success',
              cancelButtonClass: 'btn btn-danger',
              buttonsStyling: false,
            })
            swalWithBootstrapButtons({
              title: 'Are you sure?',
              text: "You won't be able to revert this!",
              type: 'warning',
              showCancelButton: true,
              confirmButtonText: 'Yes, delete it!',
              cancelButtonText: 'No, cancel!',
              reverseButtons: true
            }).then((result) => {
              if (result.value) {
                event.preventDefault();
                document.getElementById('delete-form-'+id).submit();
              } else if (
                // Read more about handling dismissals
                result.dismiss === swal.DismissReason.cancel
                ) {
                swalWithBootstrapButtons(
                  'Cancelled',
                  'Your Data is safe :)',
                  'error'
                  )
              }
            })
          }
        </script>

@endsection

